## Using the Taruvi Refine Vite starter

This project is a Refine v5 + MUI + TypeScript Vite SPA wired to TaruviBase.
The dev server is already running with hot reload — do NOT run `npm run dev`,
`npm install`, or build commands unless dependencies changed.

Non-negotiables, enforced by `AGENTS.md` (read it first — it is authoritative):

- **Functional app default**: real Taruvi schema + registered Refine
  resources + live data. No mockups unless explicitly requested.
- **Spec first**: write `docs/spec.md` (resources, fields, relations, provider
  meta, page list) before building.
- **UI preflight**: read `UI_Guidelines.md` in full before any UI work; import
  design tokens (`taruviTokens`) from `themeOptions.ts`; never hardcode brand
  hex values; icons come from `@mui/icons-material` `*Rounded` variants ONLY —
  **never add or import `lucide-react`** (or heroicons, react-icons, or any
  other icon package), and never list them in a blueprint's frameworks; this
  overrides any generic icon-library suggestion.
- **MUI v7**: `Grid2` does not exist in v7 — `import { Grid } from
  "@mui/material"` IS the new grid (`size={{ xs: 12, md: 6 }}` props). Never
  import `@mui/material/Grid2` or `@mui/material/Unstable_Grid2`, and never
  `bun install` a package SUBPATH — subpaths are not packages.
- **Page anatomy**: every list page ships search + at least one server-side
  filter + an active-filter chip row + pagination + the four distinct empty
  states (no data yet / no results / no matching items / unable to load), built
  to `UI_Guidelines.md` (§4.6, §4.7) and the DataGrid checklist in the skill;
  show pages carry breadcrumb + title + status chip + actions + meta +
  tabs-with-counts; destructive actions get confirmation dialogs; never render a
  blank page during load. Wrap page bodies in `src/components/PageContainer.tsx`.
- **User data**: only via the `user` provider and user/role tools — never
  custom identity tables.
- Taruvi config comes from `.env.local` (`TARUVI_SITE_URL`,
  `TARUVI_APP_SLUG`) through Vite defines in `src/taruviClient.ts`. There is
  no API key in the client and none may ever be added.
- Browser errors stream to `logs/frontend.ndjson` — read it instead of asking
  the user to open DevTools.
