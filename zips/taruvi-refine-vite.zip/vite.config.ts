import react from "@vitejs/plugin-react";
import { defineConfig, loadEnv } from "vite";
import type { Plugin } from "vite";
import fs from "node:fs";
import path from "node:path";

const CLIENT_LOG_ENDPOINT = "/__client_log";
const CLIENT_LOG_FILE = path.resolve(process.cwd(), "logs/frontend.ndjson");
const MAX_BODY_BYTES = 2 * 1024 * 1024;

const REDACT_KEYS = new Set([
  "token",
  "access_token",
  "refresh_token",
  "id_token",
  "authorization",
  "auth",
  "password",
  "passwd",
  "pwd",
  "api_key",
  "apikey",
  "secret",
  "client_secret",
  "cookie",
  "set-cookie",
  "session",
  "sessionid",
]);

const redactSensitive = (value: unknown, seen = new WeakSet<object>()): unknown => {
  if (Array.isArray(value)) {
    return value.map((item) => redactSensitive(item, seen));
  }
  if (value && typeof value === "object") {
    if (seen.has(value as object)) return "[Circular]";
    seen.add(value as object);
    const input = value as Record<string, unknown>;
    const output: Record<string, unknown> = {};
    for (const [key, keyValue] of Object.entries(input)) {
      if (REDACT_KEYS.has(key.toLowerCase())) {
        output[key] = "[REDACTED]";
      } else if (key.toLowerCase() === "url" && typeof keyValue === "string") {
        output[key] = redactUrl(keyValue);
      } else {
        output[key] = redactSensitive(keyValue, seen);
      }
    }
    return output;
  }
  return value;
};

const redactUrl = (url: string): string => {
  try {
    const parsed = new URL(url, "http://localhost");
    let touched = false;
    parsed.searchParams.forEach((_, key) => {
      if (REDACT_KEYS.has(key.toLowerCase())) {
        parsed.searchParams.set(key, "[REDACTED]");
        touched = true;
      }
    });
    return touched ? parsed.toString() : url;
  } catch {
    return url;
  }
};

const createClientLogPlugin = (): Plugin => ({
  name: "taruvi:client-log",
  apply: "serve",
  configureServer(server) {
    server.middlewares.use((req, res, next) => {
      const reqPath = req.url?.split("?")[0];
      if (reqPath !== CLIENT_LOG_ENDPOINT) {
        next();
        return;
      }

      if (req.method !== "POST") {
        res.statusCode = 405;
        res.setHeader("Allow", "POST");
        res.end("Method Not Allowed");
        return;
      }

      const chunks: Buffer[] = [];
      let totalBytes = 0;
      let aborted = false;

      req.on("data", (chunk: Buffer) => {
        if (aborted) return;
        totalBytes += chunk.length;
        if (totalBytes > MAX_BODY_BYTES) {
          aborted = true;
          res.statusCode = 413;
          res.end("Payload Too Large");
          req.destroy();
          return;
        }
        chunks.push(chunk);
      });

      req.on("error", () => {
        if (aborted) return;
        aborted = true;
        try {
          res.statusCode = 400;
          res.end("Request Error");
        } catch {
          /* noop */
        }
      });

      req.on("end", () => {
        if (aborted) return;
        try {
          const body = Buffer.concat(chunks).toString("utf8");
          if (!body.trim()) {
            res.statusCode = 204;
            res.end();
            return;
          }

          let parsed: unknown;
          try {
            parsed = JSON.parse(body);
          } catch {
            res.statusCode = 400;
            res.end("Invalid JSON");
            return;
          }

          const records = Array.isArray(parsed) ? parsed : [parsed];
          const receivedAt = new Date().toISOString();

          const lines = records
            .filter((record): record is Record<string, unknown> => !!record && typeof record === "object")
            .map((record) => {
              const safe = redactSensitive(record) as Record<string, unknown>;
              return JSON.stringify({ ...safe, server_received_at: receivedAt });
            })
            .join("\n");

          if (lines) {
            try {
              fs.mkdirSync(path.dirname(CLIENT_LOG_FILE), { recursive: true });
              fs.appendFileSync(CLIENT_LOG_FILE, `${lines}\n`, "utf8");
            } catch (writeErr) {
              server.config.logger.warn(
                `[taruvi:client-log] failed to write log: ${(writeErr as Error).message}`,
              );
            }
          }

          res.statusCode = 204;
          res.end();
        } catch (err) {
          server.config.logger.warn(
            `[taruvi:client-log] handler error: ${(err as Error).message}`,
          );
          try {
            res.statusCode = 500;
            res.end("Log handler error");
          } catch {
            /* noop */
          }
        }
      });
    });
  },
});

const DEPS_RESET_ENDPOINT = "/__taruvi_reset_deps";
const DEPS_RESET_COOLDOWN_MS = 60_000;
// Survives the config reload that server.restart() performs.
const DEPS_RESET_STATE = Symbol.for("taruvi.depsReset");

/**
 * Vite rebuilds its dependency cache when the agent adds an import mid-session.
 * After many rebuilds the cache can reference a file Vite itself answers with
 * 504 "Outdated Optimize Dep", and every load of the app is then a blank page.
 * index.html calls this endpoint when the app's modules fail to load; the
 * server rebuilds the cache from scratch and the page reloads.
 */
const createDepsRecoveryPlugin = (): Plugin => ({
  name: "taruvi:deps-recovery",
  apply: "serve",
  configureServer(server) {
    server.middlewares.use((req, res, next) => {
      if (req.url?.split("?")[0] !== DEPS_RESET_ENDPOINT) {
        next();
        return;
      }
      if (req.method !== "POST") {
        res.statusCode = 405;
        res.setHeader("Allow", "POST");
        res.end("Method Not Allowed");
        return;
      }
      const state = globalThis as unknown as Record<symbol, number | undefined>;
      const now = Date.now();
      res.statusCode = 202;
      if (now - (state[DEPS_RESET_STATE] ?? 0) < DEPS_RESET_COOLDOWN_MS) {
        res.end("already rebuilding");
        return;
      }
      state[DEPS_RESET_STATE] = now;
      res.end("rebuilding");
      server.config.logger.warn(
        "[taruvi:deps-recovery] the app's modules failed to load; rebuilding the dependency cache",
      );
      setTimeout(() => {
        server.restart(true).catch((err: Error) => {
          server.config.logger.error(`[taruvi:deps-recovery] restart failed: ${err.message}`);
        });
      }, 0);
    });
  },
});

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");

  return {
    define: {
      __TARUVI_SITE_URL__: JSON.stringify(env.TARUVI_SITE_URL ?? ""),
      __TARUVI_APP_SLUG__: JSON.stringify(env.TARUVI_APP_SLUG ?? ""),
      __TARUVI_API_KEY__: JSON.stringify(env.TARUVI_API_KEY ?? ""),
      __TARUVI_APP_TITLE__: JSON.stringify(env.TARUVI_APP_TITLE ?? ""),
    },
    plugins: [react(), createClientLogPlugin(), createDepsRecoveryPlugin()],
    server: {
      // Behind the platform's preview proxy the page lives on the platform
      // host while Vite listens on the container's port, so the client must
      // dial the page's host and the platform's port for its HMR socket. The
      // platform provides both; the host is left unset so Vite's client
      // falls back to the page's hostname. Without them the client dialled
      // localhost:<container port> and never connected. A container with no
      // proxy settings keeps HMR off; plain local dev keeps Vite's default.
      // The error overlay is off: while the agent writes files one at a
      // time, a page can import a module that does not exist yet, and the
      // full-screen overlay hid the working preview until the next write.
      // The error still reaches the browser console (and the agent's
      // console check); the page keeps its last good render.
      hmr: env.VITE_HMR_CLIENT_PORT
        ? {
            clientPort: Number(env.VITE_HMR_CLIENT_PORT),
            protocol: env.VITE_HMR_PROTOCOL === "wss" ? "wss" : "ws",
            overlay: false,
          }
        : process.env.CONTAINER_ENV
          ? false
          : { overlay: false },
      allowedHosts: true,
    },
    optimizeDeps: {
      // Crawl the whole source tree at server start so EVERY dependency —
      // including per-icon deep imports like @mui/icons-material/AddRounded —
      // is discovered and optimized in one pass before the first request.
      // Without this, deps discovered mid-session trigger re-optimization
      // that bumps the dep hash; a preview without a working HMR socket
      // is never told to reload and hangs on 504 "Outdated Optimize Dep"
      // responses.
      entries: ["index.html", "src/**/*.{ts,tsx}"],
      include: [
        "@emotion/react",
        "@emotion/styled",
        "hoist-non-react-statics",
        "prop-types",
        "react-is",
        "react",
        "react-dom/client",
        "react-router",
        "react-hook-form",
        "axios",
        "@mui/material",
        "@refinedev/core",
        "@refinedev/mui",
        "@refinedev/kbar",
        "@refinedev/react-router",
        "@refinedev/react-hook-form",
        "@taruvi/sdk",
        "@taruvi/refine-providers"
      ],
      esbuildOptions: {
        target: "esnext"
      }
    },
    build: {
      commonjsOptions: {
        include: [/node_modules/],
        transformMixedEsModules: true
      }
    }
  };
});
